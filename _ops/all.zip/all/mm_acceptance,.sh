#!/usr/bin/env bash
set -euo pipefail
BASE="${BASE:-http://127.0.0.1:3000}"
CKA=$(curl -s -D - -o /dev/null "$BASE/api/anon/init" | awk '/^Set-Cookie:/ {print $2}' | head -n1 | sed 's/;.*//')
CKB=$(curl -s -D - -o /dev/null "$BASE/api/anon/init" | awk '/^Set-Cookie:/ {print $2}' | head -n1 | sed 's/;.*//')
curl -s -X POST "$BASE/api/rtc/enqueue" -H "Cookie: $CKA" -H 'content-type: application/json' -d '{"gender":"male","country":"DE","genders":"all","countries":"ALL"}' >/dev/null
curl -s -X POST "$BASE/api/rtc/enqueue" -H "Cookie: $CKB" -H 'content-type: application/json' -d '{"gender":"female","country":"DE","genders":"all","countries":"ALL"}' >/dev/null
J=$(curl -s -X POST "$BASE/api/rtc/matchmake" -H "Cookie: $CKA" -H 'content-type: application/json' -d '{}')
echo "$J" | jq . || echo "$J"
PAIR=$(echo "$J" | sed -nE 's/.*"pairId":"([^"]+)".*/\1/p')
PEER=$(echo "$J" | sed -nE 's/.*"peerAnonId":"([^"]+)".*/\1/p')
META=$(echo "$J" | sed -nE 's/.*"peerMeta":\{[^}]+\}.*/ok/p')
echo "-- Acceptance --"
echo "INITIAL_PAIR_OK=$([ -n "$PAIR" ] && [ -n "$PEER" ] && echo 1 || echo 0)"
echo "PEER_META_ON_MATCH=$([ "$META" = "ok" ] && echo 1 || echo 0)"
