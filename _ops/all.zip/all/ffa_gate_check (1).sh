#!/usr/bin/env bash
set -euo pipefail
BASE="${BASE:-https://www.ditonachat.com}"
J=$(curl -fsS "${BASE}/api/rtc/env")
echo "$J" | jq . || echo "$J"
FFA=$(echo "$J" | jq -r '.FREE_FOR_ALL // 0')
NFFA=$(echo "$J" | jq -r '.NEXT_PUBLIC_FREE_FOR_ALL // 0')
echo "-- Acceptance --"
echo "FFA_PREV_ENABLED=$([ "$FFA" = "1" -o "$NFFA" = "1" ] && echo 1 || echo 0)"
