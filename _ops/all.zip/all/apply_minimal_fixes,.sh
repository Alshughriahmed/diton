#!/usr/bin/env bash
set -euo pipefail
ROOT="${1:-.}"
STAMP="$(date -u +%Y%m%d-%H%M%S)"
BK="${ROOT}/_ops/backups/${STAMP}_min"
PATCH_DIR="${PATCH_DIR:-$(pwd)/diton_patches_min}"
mkdir -p "${BK}"

backup(){
  local f="$1"
  if [[ -f "${ROOT}/$f" ]]; then
    mkdir -p "${BK}/$(dirname "$f")"
    cp -a "${ROOT}/$f" "${BK}/$f"
  fi
}

echo "[*] Backing up..."
backup "src/app/api/rtc/matchmake/route.ts"
backup "src/app/api/rtc/env/route.ts"
backup "src/state/filters.ts"
backup "src/components/chat/ChatToolbar.tsx"
backup "src/app/chat/components/FilterBar.tsx"
backup "src/components/filters/GenderSelect.tsx"
backup "src/components/filters/CountrySelect.tsx"
backup "src/app/chat/ChatClient.tsx"
backup "src/app/chat/msgSendClient.ts"

echo "[*] Applying patches (git apply)"
git -C "${ROOT}" apply --whitespace=nowarn -p0 < "${PATCH_DIR}/01_matchmake_mapped_peer_meta.diff" || true
git -C "${ROOT}" apply --whitespace=nowarn -p0 < "${PATCH_DIR}/02_env_include_ffa.diff" || true
# add utils/ffa.ts
mkdir -p "${ROOT}/src/utils"
if [[ ! -f "${ROOT}/src/utils/ffa.ts" ]]; then
  install -m 0644 "${PATCH_DIR}/03_add_utils_ffa.ts" "${ROOT}/src/utils/ffa.ts"
fi
git -C "${ROOT}" apply --whitespace=nowarn -p0 < "${PATCH_DIR}/03a_filters_runtime_ffa.diff" || true
git -C "${ROOT}" apply --whitespace=nowarn -p0 < "${PATCH_DIR}/03b_toolbar_runtime_ffa.diff" || true
git -C "${ROOT}" apply --whitespace=nowarn -p0 < "${PATCH_DIR}/03c_filterbar_runtime_ffa.diff" || true
git -C "${ROOT}" apply --whitespace=nowarn -p0 < "${PATCH_DIR}/04_chatclient_bridge_ffa.diff" || true
git -C "${ROOT}" apply --whitespace=nowarn -p0 < "${PATCH_DIR}/05_msgsend_dc_send.diff" || true
git -C "${ROOT}" apply --whitespace=nowarn -p0 < "${PATCH_DIR}/07_chatclient_like_bridge.diff" || true

echo
echo "-- Acceptance --"
echo "PATCHES_APPLIED=1"
echo "BACKUP_DIR=${BK}"
echo "ROLLBACK_HINT=cp -a '${BK}'/* ."
