export const DEFAULT_LANG = "en";
export const AUTO_TRANSLATE = false;   // can be toggled later by feature flag
export const FREE_FOR_ALL = false;     // soft-gating switch if you want to open up limits temporarily
