FROZEN 20250926-201422 — read-only snapshot. Do not edit.
