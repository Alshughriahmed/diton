import ChatClient from './ChatClient';

export default function ChatPage() {
  return <ChatClient />;
}